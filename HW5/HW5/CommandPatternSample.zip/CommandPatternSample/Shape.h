/*
 * Shape.h
 *
 *  Created on: 2009/11/29
 *      Author: zwshen
 */

#ifndef SHAPE_H_
#define SHAPE_H_

#include <string>
using namespace std;

class Shape {
public:
	enum ShapeType {
		CircleType = 0, TriangleType = 1
	};
	Shape();
	virtual ~Shape();
	virtual string toString()= 0;
};

#endif /* SHAPE_H_ */
