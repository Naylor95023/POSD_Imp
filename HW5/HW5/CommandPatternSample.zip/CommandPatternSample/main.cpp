#include <iostream>
#include "Model.h"
#include "View.h"
#include "Presentation.h"
#include "assert.h"

using namespace std;

int main() {
	Model model;
	Presentation presentation(&model);
	View view(&presentation);
    // test initial condition 
	assert(model.toString() == "shapes: ");
    // test empty undo and redo
	view.action_undo();
	assert(model.toString() == "shapes: ");
	view.action_redo();
	assert(model.toString() == "shapes: ");
    // test addShape
	view.action_addShape(Shape::CircleType);
	view.action_addShape(Shape::CircleType);
	view.action_addShape(Shape::TriangleType);
	view.action_addShape(Shape::CircleType);
	view.action_addShape(Shape::TriangleType);
	assert(model.toString() == "shapes: Circle Circle Triangle Circle Triangle");
    // test undo
	view.action_undo();
	view.action_undo();
	assert(model.toString() == "shapes: Circle Circle Triangle");
	view.action_undo();
	view.action_undo();
	view.action_undo();
	assert(model.toString() == "shapes: ");
    // test redo
	view.action_redo();
	view.action_redo();
	view.action_redo();
	assert(model.toString() == "shapes: Circle Circle Triangle");
	view.action_redo();
	view.action_redo();
	assert(model.toString() == "shapes: Circle Circle Triangle Circle Triangle");
	view.action_redo();
	assert(model.toString() == "shapes: Circle Circle Triangle Circle Triangle");
    // test new command
	view.action_undo();
	view.action_undo();
	view.action_addShape(Shape::TriangleType);
	view.action_addShape(Shape::CircleType);
	assert(model.toString() == "shapes: Circle Circle Triangle Triangle Circle");
	view.action_redo();
	assert(model.toString() == "shapes: Circle Circle Triangle Triangle Circle");
	view.action_undo();
	assert(model.toString() == "shapes: Circle Circle Triangle Triangle");
	// All tests passed
	cout << "All tests passed!\n\n";
	// Wait for user input and then terminiate
	cout << "Press enter to terminate: ";
	cin.get();
	return 0;
}
