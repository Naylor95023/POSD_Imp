/*
 * View.cpp
 *
 *  Created on: 2009/11/29
 *      Author: zwshen
 */

#include "View.h"

View::View(Presentation* p) {
	m_presentation = p;
}

View::~View() {
}

void View::action_addShape(Shape::ShapeType st) {
	m_presentation->addShape(st);
}

void View::action_redo() {
	m_presentation->redo();
}

void View::action_undo() {
	m_presentation->undo();
}