/*
 * Model.h
 *
 *  Created on: 2009/11/29
 *      Author: zwshen
 */

#ifndef MODEL_H_
#define MODEL_H_

#include "Shape.h"
#include <vector>
using namespace std;

class Model {
private:
	vector<Shape*> m_shapes;
	Shape* createShape(Shape::ShapeType);
public:
	Model();
	virtual ~Model();
	void addShape(Shape::ShapeType);
	void deleteLastShape();
	string toString();
};

#endif /* MODEL_H_ */
