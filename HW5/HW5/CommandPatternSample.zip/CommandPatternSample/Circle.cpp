/*
 * Circle.cpp
 *
 *  Created on: 2009/11/29
 *      Author: zwshen
 */

#include "Circle.h"

Circle::Circle() {
}

Circle::~Circle() {
}

string Circle::toString() {
	return "Circle";
}
