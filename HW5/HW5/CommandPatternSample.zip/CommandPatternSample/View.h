/*
 * View.h
 *
 *  Created on: 2009/11/29
 *      Author: zwshen
 */

#ifndef VIEW_H_
#define VIEW_H_
#include "Presentation.h"

class View {
private:
	Presentation* m_presentation;
public:
	View(Presentation* p);
	virtual ~View();
	// UI actions
	void action_addShape(Shape::ShapeType st);
	void action_redo();
	void action_undo();
};

#endif /* VIEW_H_ */
