/*
 * Presentation.cpp
 *
 *  Created on: 2009/12/9
 *      Author: zwshen
 */

#include "Presentation.h"
#include "AddCommand.h"

Presentation::Presentation(Model* m) {
	m_model = m;
}

Presentation::~Presentation() {
}

void Presentation::addShape(Shape::ShapeType st)
{
	// Create AddCommand and request m_CmdManager to
	//   store and execute the command
	m_CmdManager.execute(new AddCommand(m_model, st));
}

void Presentation::redo() {
	m_CmdManager.redo();
}

void Presentation::undo() {
	m_CmdManager.undo();
}
