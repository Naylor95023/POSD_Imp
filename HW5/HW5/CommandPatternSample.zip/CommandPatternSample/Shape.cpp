/*
 * Shape.cpp
 *
 *  Created on: 2009/11/29
 *      Author: zwshen
 */

#include "Shape.h"

Shape::Shape() {
}

Shape::~Shape() {
}
