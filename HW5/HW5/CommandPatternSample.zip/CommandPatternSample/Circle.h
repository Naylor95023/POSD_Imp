/*
 * Circle.h
 *
 *  Created on: 2009/11/29
 *      Author: zwshen
 */

#ifndef CIRCLE_H_
#define CIRCLE_H_

#include "Shape.h"

class Circle: public Shape {
public:
	Circle();
	virtual ~Circle();
	virtual string toString();
};

#endif /* CIRCLE_H_ */
