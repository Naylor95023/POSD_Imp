/*
 * Triangle.cpp
 *
 *  Created on: 2009/11/29
 *      Author: zwshen
 */

#include "Triangle.h"

Triangle::Triangle() {
}

Triangle::~Triangle() {
}

string Triangle::toString() {
	return "Triangle";
}
