/*
 * Triangle.h
 *
 *  Created on: 2009/11/29
 *      Author: zwshen
 */

#ifndef TRIANGLE_H_
#define TRIANGLE_H_

#include "Shape.h"

class Triangle: public Shape {
public:
	Triangle();
	virtual ~Triangle();
	virtual string toString();
};

#endif /* TRIANGLE_H_ */
