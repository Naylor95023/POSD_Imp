/*
 * AddCommand.cpp
 *
 *  Created on: 2009/11/29
 *      Author: zwshen
 */

#include "AddCommand.h"
#include "Shape.h"

AddCommand::AddCommand(Model* m, Shape::ShapeType type) {
	model = m;
	m_type = type;
}

AddCommand::~AddCommand() {
}

void AddCommand::execute() {
	model->addShape(m_type);
}

void AddCommand::unexecute() {
	model->deleteLastShape();
}