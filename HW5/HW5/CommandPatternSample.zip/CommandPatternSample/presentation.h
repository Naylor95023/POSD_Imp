/*
 * Presentation.h
 *
 *  Created on: 2009/12/9
 *      Author: zwshen
 */

#ifndef PRESENTATION_H_
#define PRESENTATION_H_

#include "CommandManager.h"
#include "model.h"
#include "shape.h"

class Presentation {
private:
	CommandManager m_CmdManager;
	Model* m_model;
public:
	Presentation(Model* model);
	virtual ~Presentation();
	void addShape(Shape::ShapeType st);
	void redo();
	void undo();
};

#endif /* PRESENTATION_H_ */
