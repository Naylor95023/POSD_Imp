#include "cppunitlite/TestHarness.h"

//#include "utShape.h"
//#include "utGraphics.h"
//#include "utHW3.h"
#include "utTryQt.h"
//#include "utVisitor.h"

int main(int argc, char** argv) {
	TestResult tr;
	TestRegistry::runAllTests(tr);

	return 0;
}

