#ifndef SHAPE_H
#define SHAPE_H

#include <string>
#include <vector>
#include <iostream>
using std::string;
using std::vector;
using std::ostream;

class Shape {
private:
	string _name;
public:
	Shape (string name);
	string name();
	virtual string print();
	virtual int area() const;
};

class Circle : public Shape {
private:
	int _cx, _cy;
	int _radius;
public:
	Circle (int cx, int cy, int radius);
	string print();
	virtual int area() const;
};

class Square : public Shape{
private:
	int _ulx, _uly;
	int _length;
public:
	Square (int ulx, int uly, int length);
	string print();
	virtual int area() const;
};

class Line : public Shape {
private:
	int _bx, _by;
	int _ex, _ey;
public:
	Line (int bx, int by, int ex, int ey);
	string print();
};

class Point : public Shape {
private:
	int _x, _y;
public:
	Point (int x, int y);
	string print();
};

string printShape(vector<Shape *> shapes);
int totalArea(vector<Shape *> shapes);

class Rectangle: public Shape {
private:
	Point _ulc;
	int _l, _w;
public:
	Rectangle (Point p, int l, int w);
	string print();
	int area() const;
};

ostream & operator << (ostream &, Shape & s);
#endif
