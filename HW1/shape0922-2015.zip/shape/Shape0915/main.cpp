#include "cppunitlite/TestHarness.h"
#include "Circle.h"
#include "Square.h"
#include <vector>

int main(int argc, char** argv) {
	TestResult tr;
	TestRegistry::runAllTests(tr);

	return 0;
}

TEST(Shapes0915, first_success) {
    CHECK(true);
}

TEST(Circle, area) {
    Circle circle(0,0,1);
    LONGS_EQUAL(3,circle.area());
}

TEST(areaSum, CIRCLE) {
    Circle c1(0,0,1), c2(0,0,2),c3(0,0,3);
    std::vector<Shape *> v;
    v.push_back(&c1);
    v.push_back(&c2);
    v.push_back(&c3);
    LONGS_EQUAL(42,areaSum(v));
}

TEST(AreaSum, Square) {
    Square c1(0,0,1), c2(0,0,2),c3(0,0,3);
    std::vector<Shape *> v;
    v.push_back(&c1);
    v.push_back(&c2);
    v.push_back(&c3);
    LONGS_EQUAL(14,areaSum(v));
}

TEST(AreaSum, SquareCircle) {
    Circle c1(0,0,1);
    Square c2(0,0,2),c3(0,0,3);
    std::vector<Shape *> v;
    v.push_back(&c1);
    v.push_back(&c2);
    v.push_back(&c3);
    LONGS_EQUAL(16,areaSum(v));
}
