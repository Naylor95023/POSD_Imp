#ifndef SHAPE_H_INCLUDED
#define SHAPE_H_INCLUDED

class Shape {
public:
    virtual int area() = 0;
};

#endif // SHAPE_H_INCLUDED
