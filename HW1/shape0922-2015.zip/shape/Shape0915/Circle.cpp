#include "Circle.h"

const int PI=3;

Circle::Circle(int center_x, int center_y, int radius)
    :cx(center_x),cy(center_y),r(radius) {}
int Circle::area() {return PI*r*r;}

int areaSum(std::vector<Shape *> v) {
    int sum = 0;
    std::vector<Shape *>::iterator i;
    for (i=v.begin(); i != v.end(); ++i)
        sum += (*i)->area();
    return sum;
}
