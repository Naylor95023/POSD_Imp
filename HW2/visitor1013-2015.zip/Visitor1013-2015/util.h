#ifndef UTIL_H_INCLUDED
#define UTIL_H_INCLUDED
#include "Shape.h"
#include <vector>

int areaSum(std::vector<Shape *> v);

#endif // UTIL_H_INCLUDED
